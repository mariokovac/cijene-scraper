﻿using CijeneScraper.Services;
using Microsoft.AspNetCore.Mvc;

namespace CijeneScraper.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class ScraperController : ControllerBase
    {
        private readonly ScrapingQueue _queue;
        private readonly ILogger<ScraperController> _logger;

        public ScraperController(ScrapingQueue queue, ILogger<ScraperController> logger)
        {
            _queue = queue;
            _logger = logger;
        }

        [HttpPost("start")]
        public IActionResult StartScraping()
        {
            _logger.LogInformation("Zahtjev za scrapanje primljen.");

            _queue.Enqueue(async token =>
            {
                // Ovamo stavi stvarni scraper
                await Task.Delay(3000, token); // simulacija scrapanja
                Console.WriteLine($"Scrapanje obavljeno u {DateTime.Now}");
            });

            return Accepted("Scrapanje dodano u red.");
        }
    }
}
