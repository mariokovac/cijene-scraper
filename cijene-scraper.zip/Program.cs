
using CijeneScraper.Services;
using NSwag.AspNetCore;

namespace CijeneScraper
{
    public class Program
    {
        public static void Main(string[] args)
        {
            var builder = WebApplication.CreateBuilder(args);

            // Add services to the container.
            builder.Services.AddControllers();
            builder.Services.AddSingleton<ScrapingQueue>();
            builder.Services.AddHostedService<ScrapingWorker>();

            builder.Services.AddOpenApiDocument();

            var app = builder.Build();

            app.UseOpenApi();

            app.UseSwaggerUi(c =>
            {
                c.Path = "/swagger";
                c.DocumentPath = "/swagger/v1/swagger.json";
            });

            app.UseHttpsRedirection();

            app.UseAuthorization();

            app.MapOpenApi();

            app.MapControllers();

            app.Run();
        }
    }
}
